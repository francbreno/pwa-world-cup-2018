import React from 'react';

import './Match.css';

const Match = () => (
  <div>
    <p>Match</p>
  </div>
);

export default Match;